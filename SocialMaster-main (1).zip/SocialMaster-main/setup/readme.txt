1)	Install Python 3.10.6 https://www.python.org/downloads/release/python-3106/

2) 	Install https://ffmpeg.org/download.html

ONLY RUN FIRST_TIME the once, you only need to run it when you setup the bot on the computer/platform/vps

3) 	run first_time.py first as admin/with elevated perms if possible.

4) 	Duplicate the original SocialMaster spreadsheet, and give access to socialmaster@socialmaster.iam.gserviceaccount.com

	then paste your spreadsheet key into spreadsheet key txt file

	the key should be like 1i5wCiGWvEd1sTn0V_ifzzvfm3d0j6d1dlXFg6xyH9Sk

	it is the part inbetween the /d/ and /edit in a spreadsheet url

	https://docs.google.com/spreadsheets/d/ 1i5wCiGWvEd1sTn0V_ifzzvfm3d0j6d1dlXFg6xyH9Sk /edit#gid=0

5)	Done